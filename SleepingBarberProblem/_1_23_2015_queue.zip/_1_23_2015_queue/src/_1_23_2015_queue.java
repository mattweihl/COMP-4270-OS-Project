public class _1_23_2015_queue {

   
    public static void main(String[] args) {
       Queue q = new Queue(5);
       q.enqueue(5);
       q.enqueue(10);
       q.peek();
       q.enqueue(12);
       q.enqueue(15);
       q.enqueue(22);
       q.enqueue(30);
       q.peek();
       q.dequeue();
       q.dequeue();
       q.enqueue(44);
       q.peek();
    
 
    }//end main
    
}//end class
