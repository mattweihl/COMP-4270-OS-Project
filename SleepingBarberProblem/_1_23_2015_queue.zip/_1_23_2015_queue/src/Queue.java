public class Queue {
    public int[] q;
    int first = 0;
    int last = -1;
    int size = 0;
    int maxsize;
    
    public Queue(int maxsize){
        this.maxsize = maxsize;
        q = new int[maxsize];
        //creates array at whatever size I want
    }//end queue
    
    public void enqueue(int n){
        if(size == maxsize){
            System.out.println("Queue is full...try another line.");
        }else{
            last++;
            q[last%maxsize] = n;
            size++;
            System.out.println("Enqueing "+n);
        }//end if
    }//end enqueue
    
    public int dequeue(){
        if(size == 0){
            System.out.println("Queue is empty.");
            return -1;
        }else{
            int temp = q[first];
            System.out.println("Dequeueing "+temp);
            q[first] = 0;
            first = (first+1)%maxsize;
            size--;
            return temp;
        }//end if
    }//end dequeue
    
    
    public void peek(){
        if(size == 0){
            System.out.println("[]");   
        }else{
            int temp = first;
            for(int i = 0; i<size; i++){
                System.out.println("["+q[temp%maxsize]+"]");
                temp++;
                
            }//end for
        }//end if
        
    }//end peek
    
    
    
}//end Queue
